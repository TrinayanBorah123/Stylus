
package stylusproject;

import com.jfoenix.controls.JFXDatePicker;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import static stylusproject.EmployeeLoginFXMLController.sid;


public class EmployeeStatusFXMLController implements Initializable {

    @FXML
    private Pane lab;
    @FXML
    private Label lab2;
    @FXML
    private Label lab1;
    @FXML
    private Label lab3;
    @FXML
    private JFXDatePicker mdate;
    @FXML
    private Label lab4;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void back(ActionEvent event) throws IOException {
          
       ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeLoginDataFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
     SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy"); 
    public LoginModel loginmodel=new LoginModel();
    @FXML
    private void search(ActionEvent event) throws SQLException, ParseException {
          if(!mdate.getEditor().getText().isEmpty() && loginmodel.isEmployeeSearchLogin(sid,mdate.getEditor().getText())){
           lab2.setText("Employee Status Check");
      String v1=mdate.getEditor().getText();
      String odate="yyyy-MM-dd";
      SimpleDateFormat inputformat=new SimpleDateFormat("dd/MM/yyyy");
       SimpleDateFormat inputformat1=new SimpleDateFormat("MM/dd/yyyy");
      SimpleDateFormat outputformat=new SimpleDateFormat(odate);
      Date date=null;
      String rqdate=null;
      rqdate=outputformat.format(inputformat.parse(v1));
      String  rqdate1=outputformat.format(inputformat1.parse(v1));
      
           Connection conn=dbConnect.Connector();
      
        try {
             ResultSet rs = conn.createStatement().executeQuery("select status,workdone,income from STYLUS.EmpStatus where id='"+sid+"'and wdate in('"+(rqdate)+"','"+(v1)+"','"+rqdate1+"')");
             rs.next();
             String s1=rs.getString(1);
             String s2=rs.getString(2);
             String s3=rs.getString(3);
             lab1.setText(s1);
             lab3.setText(s2);
             lab4.setText(s3);
         } catch (SQLException ex) {
            System.out.println(ex);
        
        }
        }else
        {   lab1.setText("No data!");
            lab2.setText("Give proper input!");
            lab3.setText("No data!");
             lab4.setText("No data!");
        }
     
    }

    @FXML
    private void reset(ActionEvent event) {
        this.lab2.setText("Employee Status Check");
        this.mdate.setValue(null);
        this.lab1.setText("_______________________");
        this.lab3.setText("_______________________");
        this.lab4.setText("_______________________");
    }
    
}
