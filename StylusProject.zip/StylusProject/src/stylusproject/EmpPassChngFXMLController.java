
package stylusproject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import static stylusproject.EmployeeLoginFXMLController.sid;
import static stylusproject.OwnerLoginFXMLController.oid;


public class EmpPassChngFXMLController implements Initializable {

    @FXML
    private AnchorPane ap;
    @FXML
    private Pane lab;
    @FXML
    private Label lab3;
    @FXML
    private Label isConnected;
    @FXML
    private Label lab1;
    @FXML
    private Label lab2;
    @FXML
    private JFXTextField oldpass;
    @FXML
    private JFXButton b1;
    @FXML
    private JFXButton b2;
    @FXML
    private JFXPasswordField conpass;
    @FXML
    private Label lab21;
    @FXML
    private JFXPasswordField newpass;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    public LoginModel loginmodel=new LoginModel();
    @FXML
    private void change(ActionEvent event) throws SQLException {
         if(loginmodel.isLoginEmp(sid, oldpass.getText()) && !conpass.getText().isEmpty() && !oldpass.getText().isEmpty() && !newpass.getText().isEmpty() && (newpass.getText().equals(conpass.getText()))){
       String v1=oldpass.getText();
       String v2=newpass.getText();
       //String v3=conpass.getText(); 
       String queryUpdate="update STYLUS.EmpTab set password='"+v2+"'where id='"+sid+"'";     
      try{
      Connection conn= dbConnect.Connector();  
      PreparedStatement smt= conn.prepareStatement(queryUpdate);
      smt.execute();
      conn.close();
      isConnected.setText("Updated Sucessfully");
     }catch(Exception e){
         System.out.println(e);
     }
     }else{
       isConnected.setText("Error Updating");
       }
    }

    @FXML
    private void home(ActionEvent event) throws IOException {
         ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeLoginDataFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    
}
