
package stylusproject;


public class EmployeeStatusData {

      private String id;
     private String email;
     private String work;
     private String status;
     private String date;
      private String income;
      private String worktype;
     
     public EmployeeStatusData(String Id,String Email,String Work,String Status,String Date,String Income,String WorkType){
       this.id=Id;
       this.email=Email;
       this.work=Work;
       this.status=Status;
       this.date=Date;
        this.income=Income;
        this.worktype=WorkType;
     }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the work
     */
    public String getWork() {
        return work;
    }

    /**
     * @param work the work to set
     */
    public void setWork(String work) {
        this.work = work;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the income
     */
    public String getIncome() {
        return income;
    }

    /**
     * @param income the income to set
     */
    public void setIncome(String income) {
        this.income = income;
    }

    /**
     * @return the worktype
     */
    public String getWorktype() {
        return worktype;
    }

    /**
     * @param worktype the worktype to set
     */
    public void setWorktype(String worktype) {
        this.worktype = worktype;
    }
     
}
