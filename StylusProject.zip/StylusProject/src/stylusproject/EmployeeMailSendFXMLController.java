
package stylusproject;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class EmployeeMailSendFXMLController implements Initializable {

    @FXML
    private Pane lab;
    @FXML
    private Label lab2;
    @FXML
    private JFXTextField id;
    @FXML
    private JFXTextArea message;
    @FXML
    private Label lab1;
     public LoginModel loginmodel=new LoginModel();
    
  
     private dbConnect connection;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
           this.connection=new dbConnect();
    } 
     private String recipient="";
     private String mes="";
    @FXML
    private void sendmail(ActionEvent event) throws SQLException, AddressException, MessagingException {
        if(!id.getText().isEmpty() && !message.getText().isEmpty() && loginmodel.isEmpStatusInsert(id.getText())){
          mes=message.getText();
        Connection conn=dbConnect.Connector();
         ResultSet rs=null;
        String v1=id.getText();
        try {
             rs = conn.createStatement().executeQuery("select email from STYLUS.EmpTab where id='"+v1+"'");
             rs.next();
             String s1=rs.getString(1);  
             recipient=s1;
             lab1.setText(s1);
         } catch (SQLException ex) {
            System.out.println(ex);
         }
        
        //Mail Sending Section
        
       String host="smtp.gmail.com";
       final String user="stylusprivatelimited123@gmail.com";
       final String password="stylus123";
       String to=recipient;
       
       Properties props=new Properties();
       props.put("mail.smtp.host",host);
       props.put("mail.smtp.auth", "true");
       props.put("mail.smtp.port", "465");
       props.put("mail.smtp.auth", "true");
       props.put("mail.smtp.socketFactory.port","465");
       props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
       
       Session session=Session.getDefaultInstance(props,
           new javax.mail.Authenticator(){
            protected PasswordAuthentication getPasswordAuthentication(){
              return new PasswordAuthentication(user,password);
            }
        });
       
       
       
       try{
       
         MimeMessage message=new MimeMessage(session);
        message.setFrom(new InternetAddress(user));
       message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
       message.setSubject("COUPON CODE FROM WORKPLACE");
       message.setText(mes);
       Transport.send(message);
       lab2.setText("Message sent succesfully");
       }
       catch(MessagingException e){
          System.out.println(e);
       }
        
       
       //lab1.setText(recipient);
        }
        else{
            lab1.setText("No data Found!");
            lab2.setText("Give proper Input!");
        }
    
    }
    
    

    @FXML
    private void next(ActionEvent event) throws SQLException {
         if(!id.getText().isEmpty() && (!message.getText().isEmpty() || message.getText().isEmpty()) && loginmodel.isEmpStatusInsert(id.getText())){
      
        Connection conn=dbConnect.Connector();
        ResultSet rs=null;
        String v1=id.getText();
        try {
             rs = conn.createStatement().executeQuery("select email from STYLUS.EmpTab where id='"+v1+"'");
             rs.next();
             String s1=rs.getString(1);  
             lab1.setText(s1);
         } catch (SQLException ex) {
            System.out.println(ex);
         }
        lab2.setText("Now CONFIRM & SEND your mail..");
        }
        else{
            lab1.setText("No data Found!");
            lab2.setText("Give proper Input!");
        }
    
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
         ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("OwnerLoginDataFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }

    @FXML
    private void reset(ActionEvent event) {
          this.id.setText("");
        this.message.setText("");
        this.lab2.setText("Employee Mail Sending Menu");
        this.lab1.setText("____________________");
    }
    
}
