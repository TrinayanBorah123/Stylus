
package stylusproject;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class LoginModel {
     Connection connection;
    public LoginModel(){
    connection =dbConnect.Connector();
   // if(connection==null)
       // System.exit(1);
    }
    public boolean isDBConnected(){
        try {
          return !connection.isClosed();
        } catch (SQLException ex) {
           ex.printStackTrace();
           return false;
        }
    }
     public boolean isBookDelete(String fn,String ph) throws SQLException{
      PreparedStatement preparedstatement=null;
      ResultSet resultset=null;
      String query="SELECT * from STYLUS.Booking where fname= ? and phone=?";
        try{
            
            preparedstatement=connection.prepareStatement(query);
            preparedstatement.setString(1,fn);
            preparedstatement.setString(2,ph);
            resultset=preparedstatement.executeQuery();
            if(resultset.next())
            {return true;}
            else
            {return false;}
      }catch(Exception e){
        return false;
      }finally{
        preparedstatement.close();
        resultset.close();
        }
    }
     public boolean isLogin(String userid,String pass) throws SQLException{
      PreparedStatement preparedstatement=null;
      ResultSet resultset=null;
      String query="SELECT * from STYLUS.OwnerTab where id= ? and password=?";
        try{
            
            preparedstatement=connection.prepareStatement(query);
            preparedstatement.setString(1,userid);
            preparedstatement.setString(2,pass);
            resultset=preparedstatement.executeQuery();
            if(resultset.next())
            {return true;}
            else
            {return false;}
      }catch(Exception e){
        return false;
      }finally{
        preparedstatement.close();
        resultset.close();
        }
    }
      public boolean isLoginEmp(String userid,String pass) throws SQLException{
      PreparedStatement preparedstatement=null;
      ResultSet resultset=null;
      String query="SELECT * from STYLUS.EmpTab where id= ? and password=?";
        try{
            
            preparedstatement=connection.prepareStatement(query);
            preparedstatement.setString(1,userid);
            preparedstatement.setString(2,pass);
            resultset=preparedstatement.executeQuery();
            if(resultset.next())
            {return true;}
            else
            {return false;}
      }catch(Exception e){
        return false;
      }finally{
        preparedstatement.close();
        resultset.close();
        }
    }
        public boolean isEmpStatusInsert(String userid) throws SQLException{
      PreparedStatement preparedstatement=null;
      ResultSet resultset=null;
      String query="SELECT * from STYLUS.EmpTab where id= ?";
        try{
            
            preparedstatement=connection.prepareStatement(query);
            preparedstatement.setString(1,userid);
            resultset=preparedstatement.executeQuery();
            if(resultset.next())
            {return true;}
            else
            {return false;}
      }catch(Exception e){
        return false;
      }finally{
        preparedstatement.close();
        resultset.close();
        }
    }
         public boolean isEmpInsertData(String userid,String cdate) throws SQLException{
      PreparedStatement preparedstatement=null;
      ResultSet resultset=null;
      String query="SELECT * from STYLUS.EmpStatus where id= ? and wdate=?";
        try{
            
            preparedstatement=connection.prepareStatement(query);
            preparedstatement.setString(1,userid);
            preparedstatement.setString(2,cdate);
            resultset=preparedstatement.executeQuery();
            if(resultset.next())
            {return true;}
            else
            {return false;}
      }catch(Exception e){
        return false;
      }finally{
        preparedstatement.close();
        resultset.close();
        }
    }
         
          public boolean isEmployeeSearchLogin(String id,String edate) throws SQLException, ParseException{
      //PreparedStatement preparedstatement=null;
      //ResultSet resultset=null;
       String odate="yyyy-MM-dd";
      SimpleDateFormat inputformat=new SimpleDateFormat("dd/MM/yyyy");
      
      SimpleDateFormat outputformat=new SimpleDateFormat(odate);
      Date date=null;
      String rqdate=null;
      //date=inputformat.parse(edate);
      rqdate=outputformat.format(inputformat.parse(edate));
       SimpleDateFormat inputformat1=new SimpleDateFormat("MM/dd/yyyy"); 
      String  rqdate1=outputformat.format(inputformat1.parse(edate));
     
      String query="SELECT * from STYLUS.EmpStatus where id=? and wdate in('"+rqdate+"','"+edate+"','"+rqdate1+"')";
        try{
            
          PreparedStatement   preparedstatement=connection.prepareStatement(query);
            preparedstatement.setString(1,id);
           // preparedstatement.setString(2,rqdate);
          ResultSet  resultset=preparedstatement.executeQuery();
            if(resultset.next())
            {return true;}
            else
            {return false;}
      }catch(Exception e){
        return false;
      }finally{
        //preparedstatement.close();
        //resultset.close();
        }
    }
          
   public boolean isCustomerAgain(String fname,String lname) throws SQLException{
     // PreparedStatement preparedstatement=null;
      //ResultSet resultset=null;
      String query="SELECT * from STYLUS.CustTab where  fname=? and lname=?";
        try{
            
            PreparedStatement preparedstatement=connection.prepareStatement(query);
            preparedstatement.setString(1,fname);
            preparedstatement.setString(2,lname);
           ResultSet resultset=preparedstatement.executeQuery();
            if(resultset.next())
            {return true;}
            else
            {return false;}
      }catch(Exception e){
        return false;
      }finally{
       // preparedstatement.close();
        //resultset.close();
        }
    }       
}
