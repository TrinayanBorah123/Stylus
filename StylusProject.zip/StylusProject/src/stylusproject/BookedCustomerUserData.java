
package stylusproject;

public class BookedCustomerUserData {
     private String fname;
     private String lname;
     private String phone;
     private String bdate;
    
     
     public BookedCustomerUserData(String Fname,String Lname,String Phone,String Bdate){
       this.fname=Fname;
       this.lname=Lname;
       this.phone=Phone;
       this.bdate=Bdate;
      
     } 

    /**
     * @return the fname
     */
    public String getFname() {
        return fname;
    }

    /**
     * @param fname the fname to set
     */
    public void setFname(String fname) {
        this.fname = fname;
    }

    /**
     * @return the lname
     */
    public String getLname() {
        return lname;
    }

    /**
     * @param lname the lname to set
     */
    public void setLname(String lname) {
        this.lname = lname;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the bdate
     */
    public String getBdate() {
        return bdate;
    }

    /**
     * @param bdate the bdate to set
     */
    public void setBdate(String bdate) {
        this.bdate = bdate;
    }
     
}


