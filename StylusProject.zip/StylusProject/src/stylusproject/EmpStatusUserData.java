
package stylusproject;


public class EmpStatusUserData {
      private String date;
     private String workdone;
     private String status;
     private String income;
      private String worktype;
      public EmpStatusUserData(String Date,String Workdone,String Status,String Income,String WorkType){
       this.date=Date;
       this.workdone=Workdone;
       this.status=Status;
       this.income=Income;
       this.worktype=WorkType;
      }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the workdone
     */
    public String getWorkdone() {
        return workdone;
    }

    /**
     * @param workdone the workdone to set
     */
    public void setWorkdone(String workdone) {
        this.workdone = workdone;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the income
     */
    public String getIncome() {
        return income;
    }

    /**
     * @param income the income to set
     */
    public void setIncome(String income) {
        this.income = income;
    }

    /**
     * @return the worktype
     */
    public String getWorktype() {
        return worktype;
    }

    /**
     * @param worktype the worktype to set
     */
    public void setWorktype(String worktype) {
        this.worktype = worktype;
    }
      
}

   