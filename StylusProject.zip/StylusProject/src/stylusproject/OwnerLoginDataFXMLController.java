/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stylusproject;

import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Trinayan
 */
public class OwnerLoginDataFXMLController implements Initializable {

    @FXML
    private Pane lab;
    @FXML
    private TableView<EmployeeStatusData> EmpStatustable;
    @FXML
    private TableColumn<EmployeeStatusData, String> idcolumn;
    @FXML
    private TableColumn<EmpStatusUserData, String> emailcolumn;
    @FXML
    private TableColumn<EmployeeStatusData, String> workdonecolumn;
    @FXML
    private TableColumn<EmployeeStatusData, String> statuscolumn;
    @FXML
    private TableColumn<EmployeeStatusData, String> datecolumn;
    @FXML
    private TableColumn<EmployeeStatusData, String> incomecolumn;
     @FXML
    private TableColumn<EmployeeStatusData, String> worktypecolumn;
    private ObservableList<EmployeeStatusData> data;
    @FXML
    private TableView<BookedCustomerUserData> BookedCusttable;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Bfnamecolumn;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Blnamecolumn;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Bphonecolumn;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Bdatecolumn;
    @FXML
    private JFXTextField fn;
    @FXML
    private JFXTextField ph;
    @FXML
    private Label st;
    @FXML
    private TableView<CustUserData> CustSMStable;
    @FXML
    private TableColumn<CustUserData, String> CSMSfnamecolumn;
    @FXML
    private TableColumn<CustUserData, String> CSMSPhonecolumn;
    @FXML
    private TableColumn<CustUserData, String> CSMSCostcolumn;
    private ObservableList<CustUserData> data2;
    @FXML
    private JFXTextField phno;
    @FXML
    private JFXTextArea message1;
    @FXML
    private Label lab1;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void loaddata1(ActionEvent event) throws SQLException {
          Connection conn= dbConnect.Connector();   
        this.data = FXCollections.observableArrayList();
          
      
        ResultSet rs2=conn.createStatement().executeQuery("select id,workdone,status,cdate,income,worktype from STYLUS.EmpStatus");
         while(rs2.next()){
          ResultSet rs1=conn.createStatement().executeQuery("select email from STYLUS.EmpTab where id='"+rs2.getString(1)+"'");  
         rs1.next();
           this.data.add(new EmployeeStatusData(rs2.getString(1),rs1.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4),rs2.getString(5),rs2.getString(6)));
         
        }
         this.idcolumn.setCellValueFactory(new PropertyValueFactory<>("id"));
         this.emailcolumn.setCellValueFactory(new PropertyValueFactory<>("email"));
         this.datecolumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        this.workdonecolumn.setCellValueFactory(new PropertyValueFactory("work"));
        this.statuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        this.incomecolumn.setCellValueFactory(new PropertyValueFactory<>("income"));
         this.worktypecolumn.setCellValueFactory(new PropertyValueFactory<>("worktype"));
        //this.studenttable.setItems(null);
        this.EmpStatustable.setItems(this.data);
    }

    @FXML
    private void mail(ActionEvent event) throws IOException {
     ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeMailSendFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();   
    }

    @FXML
    private void search1(ActionEvent event) throws IOException {
        ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeDataSearchFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }

    @FXML
    private void signout(ActionEvent event) throws IOException {
        ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("FXMLDocument.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    private ObservableList<BookedCustomerUserData> data1;
    @FXML
    private void loaddata2(ActionEvent event) throws SQLException {
        Connection conn= dbConnect.Connector();
        this.data1 = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select fname,lname,phone,bdate from STYLUS.Booking");
        while(rs2.next()){
          this.data1.add(new BookedCustomerUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4)));
          }
         this.Bfnamecolumn.setCellValueFactory(new PropertyValueFactory<>("fname"));
        this.Blnamecolumn.setCellValueFactory(new PropertyValueFactory("lname"));
        this.Bphonecolumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        this.Bdatecolumn.setCellValueFactory(new PropertyValueFactory<>("bdate"));
        //this.studenttable.setItems(null);
        this.BookedCusttable.setItems(this.data1);
        conn.close();
        
    }
    public LoginModel loginmodel=new LoginModel();
    @FXML
    private void delete2(ActionEvent event) throws SQLException {
     
       if(loginmodel.isBookDelete(fn.getText(),ph.getText())&&!fn.getText().isEmpty() && !ph.getText().isEmpty()){
       String delete="delete from STYLUS.Booking where fname='"+fn.getText()+"'and phone='"+ph.getText()+"'";
       try{
         Connection conn= dbConnect.Connector();  
         PreparedStatement smt= conn.prepareStatement(delete); 
       
        smt.execute();
         this.data1 = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select fname,lname,phone,bdate from STYLUS.Booking");
        while(rs2.next()){
          this.data1.add(new BookedCustomerUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4)));
          }
         this.Bfnamecolumn.setCellValueFactory(new PropertyValueFactory<>("fname"));
        this.Blnamecolumn.setCellValueFactory(new PropertyValueFactory("lname"));
        this.Bphonecolumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        this.Bdatecolumn.setCellValueFactory(new PropertyValueFactory<>("bdate"));
        //this.studenttable.setItems(null);
        this.BookedCusttable.setItems(this.data1);
        conn.close();
        st.setText("Data deleted Sucessfully");
      }catch(SQLException ex)
      {  System.out.println(ex); 
      }
      }
      else{
          st.setText("Properly provide data");
        
      }
       
    }

    @FXML
    private void SmsSend(ActionEvent event) throws MalformedURLException, IOException {
        String mess=message1.getText();
        String phone="91"+phno.getText();
        if(!message1.getText().isEmpty() && !phno.getText().isEmpty()){
        try{
        String apiKey = "apikey=" + "OcRBz6eOBbI-KAUC3BnClxfkHDXCYBqKCrRdJ7zXM9";
			String message = "&message=" + mess;
			String sender = "&sender=" + "TXTLCL";
			String numbers = "&numbers=" +phone ;
			
			// Send data
			HttpURLConnection conn = (HttpURLConnection) new URL("https://api.textlocal.in/send/?").openConnection();
			String data = apiKey + numbers + message + sender;
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
			conn.getOutputStream().write(data.getBytes("UTF-8"));
			final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			final StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = rd.readLine()) != null) {
				//stringBuffer.append(line);
			 System.out.println(line);
                        }
			rd.close();
			
			//return stringBuffer.toString();
		} catch (Exception e) {
			System.out.println("Error SMS "+e);
			//return "Error "+e;
		}
                lab1.setText("Message sent Successfully");
        }
        else{
        lab1.setText("Error message sending!!");
        }
    }
    

    @FXML
    private void loadcust(ActionEvent event) throws SQLException {
        Connection conn= dbConnect.Connector();
        this.data2 = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select fname,phone,amount from STYLUS.CustTab");
        while(rs2.next()){
          this.data2.add(new CustUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3)));
          }
         this.CSMSfnamecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        this.CSMSPhonecolumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        this.CSMSCostcolumn.setCellValueFactory(new PropertyValueFactory<>("cost"));
        //this.studenttable.setItems(null);
        this.CustSMStable.setItems(this.data2);
        conn.close();
    }
    @FXML
    private void passchg(ActionEvent event) throws IOException{
        ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("PasswordChangeFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    
    }
     @FXML
 private void deleteAll(ActionEvent event) throws SQLException{
    Connection conn= dbConnect.Connector(); 
     String delete="delete from STYLUS.CustTab";
      String delete1="delete from STYLUS.getid";
       PreparedStatement smt2=conn.prepareStatement(delete);
    smt2.execute(); 
    PreparedStatement smt3=conn.prepareStatement(delete1);
    smt3.execute(); 
    this.data2 = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select fname,phone,amount from STYLUS.CustTab");
        while(rs2.next()){
          this.data2.add(new CustUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3)));
          }
         this.CSMSfnamecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        this.CSMSPhonecolumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        this.CSMSCostcolumn.setCellValueFactory(new PropertyValueFactory<>("cost"));
        //this.studenttable.setItems(null);
        this.CustSMStable.setItems(this.data2);
        conn.close();
        
    lab1.setText("Successfully deleted all data!!");
    
 }
   @FXML
 private void deleteEmp(ActionEvent event) throws SQLException, IOException{
    ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeDataDeleteFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
 }
}
