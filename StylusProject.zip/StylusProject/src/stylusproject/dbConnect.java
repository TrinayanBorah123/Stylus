
package stylusproject;

import java.sql.Connection;
import java.sql.DriverManager;


public class dbConnect {
     public static Connection Connector(){
    // String currentdir=System.getProperty("user.dir");
        try{
        // Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
      //   Connection conn=DriverManager.getConnection("jdbc:derby:"+currentdir+"\\stylus","stylus","root");
          
         Connection conn=DriverManager.getConnection("jdbc:derby:C:\\Users\\Trinayan\\AppData\\Roaming\\NetBeans\\Derby\\stylus","stylus","root");
          Class.forName("oracle.jdbc.driver.OracleDriver");
     //   Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@User:1521:XE","system","trinayan123");
          
          //Class.forName("org.sqlite.JDBC");
          //Connection conn=DriverManager.getConnection("jdbc:sqlite:MarketDB.sqlite");
          return conn;
      }catch(Exception e){
       System.out.println(e);
       return null;   
      }
     }
}
