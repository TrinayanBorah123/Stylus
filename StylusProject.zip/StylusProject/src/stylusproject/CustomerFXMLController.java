
package stylusproject;

import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.print.PageLayout;
import javafx.print.Printer;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.print.attribute.PrintRequestAttributeSet;


public class CustomerFXMLController implements Initializable {

    @FXML
    private Label lb;
    @FXML
    private JFXTextField fname;
    @FXML
    private JFXTextField lname;
    @FXML
    private JFXTextField amount;
    @FXML
    private JFXTextField pmethod;
    @FXML
    private JFXRadioButton male;
    @FXML
    private ToggleGroup gender;
    @FXML
    private JFXRadioButton female;
    @FXML
    private JFXTextArea rece;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXTextField gst;
    @FXML
    private JFXTextField empid;
    @FXML
    private JFXTextField offer;
     @FXML
    private JFXTextField workcode;
    public LoginModel loginmodel=new LoginModel();
    String reci="";
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void print(ActionEvent event) throws PrinterException {
           
         if((!email.getText().isEmpty() || email.getText().isEmpty()) && !fname.getText().isEmpty() && !lname.getText().isEmpty() && !amount.getText().isEmpty() && !pmethod.getText().isEmpty() && !gst.getText().isEmpty()){
       Printer printer = Printer.getDefaultPrinter();
       PageLayout page = printer.getDefaultPageLayout();
       javafx.print.PrinterJob PJ = javafx.print.PrinterJob.createPrinterJob(printer);
     
        javafx.print.PrinterJob job = javafx.print.PrinterJob.createPrinterJob();
        
       if(job != null){
        boolean Success = job.printPage(rece);
        if(Success){
            job.endJob();
        }
       
         }
       } else 
        {  lb.setText("Properly provide data");}
    
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
        ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("FXMLDocument.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }

    @FXML
    private void insert(ActionEvent event) throws SQLException {
        
        //loginmodel.isCustomerAgain(fname.getText(),lname.getText())
        String insertquery="insert into STYLUS.CustTab(rid,fname,lname,amount,pmethod,vdate,gender,phone,tamount) values(?,?,?,?,?,current_date,?,?,?)";
         String wk="1";
        if(loginmodel.isEmpStatusInsert(empid.getText()) &&!workcode.getText().isEmpty()&&(!offer.getText().isEmpty() || offer.getText().isEmpty() && !empid.getText().isEmpty() && !email.getText().isEmpty() || email.getText().isEmpty()) && !fname.getText().isEmpty() && !lname.getText().isEmpty() && !amount.getText().isEmpty() && !pmethod.getText().isEmpty() && !gst.getText().isEmpty()){
        if(offer.getText().isEmpty()){
        
           Connection conn= dbConnect.Connector();  
         PreparedStatement smt= conn.prepareStatement(insertquery); 
         ResultSet rs3=conn.createStatement().executeQuery("select count(id)+1 from STYLUS.getid");
         rs3.next();
         int getvalue=Integer.parseInt(rs3.getString(1));
         String inv="STYLUS"+getvalue;
        PreparedStatement smt1= conn.prepareStatement("insert into STYLUS.getid(id) values(select (count(*)+1) from STYLUS.getid)");
         //smt1.setString(1,String.valueOf(getvalue));
         
         
         smt1.execute();
         double gstval=Double.valueOf(gst.getText())/100;
         
        if(loginmodel.isCustomerAgain(fname.getText(),lname.getText())){  
           ResultSet rs=conn.createStatement().executeQuery("select rid,vdate,fname,lname,amount,pmethod,phone,tamount from STYLUS.CustTab where fname='"+fname.getText()+"' and lname='"+lname.getText()+"'");
           rs.next();
           java.util.Date d1=(Date.valueOf(rs.getString(2)));
         java.util.Date d2=new Date(System.currentTimeMillis());
         long days1=(d1.getTime()/(1000*60*60*24));
          long days2=(d2.getTime()/(1000*60*60*24));
          long days=Math.abs(days2-days1);
          int datedif=(int)days;
          //System.out.println(datedif);
          if(datedif<=30){ 
              if(Integer.valueOf(amount.getText())>=600){
               smt.setString(1,inv);
               smt.setString(2,fname.getText());
               smt.setString(3,lname.getText());
               smt.setDouble(4,(Integer.valueOf(amount.getText())));
               smt.setString(5,pmethod.getText());
       // smt.setString(5,vdate.getEditor().getText());
        if(male.isSelected()){
          smt.setString(6,male.getText());
        }else if(female.isSelected()){
          smt.setString(6,female.getText());
        }
         smt.setString(7,email.getText());
         smt.setDouble(8,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.15*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
         
         if(!loginmodel.isEmpInsertData(empid.getText(),String.valueOf(new Date(System.currentTimeMillis())))){
         try{
         PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,wk);
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.15*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
         }catch(Exception e){}
         }else{
          try{
             //String getdataquery="select workdone,income from STYLUS.EmpStatus where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'"; 
         String getdataquery="select count(id) from STYLUS.EmpStatus";
         ResultSet rs1=conn.createStatement().executeQuery(getdataquery);
        rs1.next();
          // Double value=Double.parseDouble(amount.getText())+Double.valueOf(rs1.getString(2));
            int value1=Integer.valueOf(rs1.getString(1))+1;
            
        PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,String.valueOf(value1));
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.15*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
       
            //String updatequery="update STYLUS.EmpStatus set workdone='"+String.valueOf(value1)+"',income='"+String.valueOf(value)+"'where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'";
           
        
     
       //   PreparedStatement smt3= conn.prepareStatement(updatequery);
         //smt3.executeUpdate();
            }catch(Exception e){
            System.out.println(e);}
        
       }
       
         
         smt.execute();
     
        ResultSet rs1=conn.createStatement().executeQuery("select amount,vdate from STYLUS.CustTab where fname='"+fname.getText()+"' and lname='"+lname.getText()+"'and vdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'");
         rs1.next();
         if(gst.getText().equals("0")){
            // if(Integer.parseInt(amount.getText())>=1000){
          //rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nDiamond Customer\n\n\tTHANK YOU");
          /*   }else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
                   rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nPlatinum Customer\n\n\tTHANK YOU");
        
             }else if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
               rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nGold Customer\n\n\tTHANK YOU");
        
             }else{  */
                   rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"r\n\n\tTHANK YOU");
        
              
         }else
         { /* if(Integer.parseInt(amount.getText())>=1000){
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nDiamond Customer\n\n\tTHANK YOU");
         }else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
           rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nPlatinum Customer\n\n\tTHANK YOU");
         
         }else if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nGold Customer\n\n\tTHANK YOU");
         
         }else{  */
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(15% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.15*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\n\n\tTHANK YOU");
        
         
         } 
              
         }else if(Integer.valueOf(amount.getText())<=600 && Integer.valueOf(amount.getText())>=300){
              
              smt.setString(1,inv);
               smt.setString(2,fname.getText());
               smt.setString(3,lname.getText());
               smt.setDouble(4,(Integer.valueOf(amount.getText())));
               smt.setString(5,pmethod.getText());
       // smt.setString(5,vdate.getEditor().getText());
        if(male.isSelected()){
          smt.setString(6,male.getText());
        }else if(female.isSelected()){
          smt.setString(6,female.getText());
        }
         smt.setString(7,email.getText());
         smt.setDouble(8,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.1*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
         
         if(!loginmodel.isEmpInsertData(empid.getText(),String.valueOf(new Date(System.currentTimeMillis())))){
         try{
         PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,wk);
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.1*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
         }catch(Exception e){}
         }else{
           try{
            // String getdataquery="select workdone,income from STYLUS.EmpStatus where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'"; 
         String getdataquery="select count(id) from STYLUS.EmpStatus";
           ResultSet rs1=conn.createStatement().executeQuery(getdataquery);
        rs1.next();
          // Double value=Double.parseDouble(amount.getText())+Double.valueOf(rs1.getString(2));
            int value1=Integer.valueOf(rs1.getString(1))+1;
            
          //  String updatequery="update STYLUS.EmpStatus set workdone='"+String.valueOf(value1)+"',income='"+String.valueOf(value)+"'where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'";
            PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,String.valueOf(value1));
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.1*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
       
     
        //  PreparedStatement smt3= conn.prepareStatement(updatequery);
        // smt3.executeUpdate();
            }catch(Exception e){
            System.out.println(e);}
        
       }
       
         
         smt.execute();
      
        ResultSet rs1=conn.createStatement().executeQuery("select amount,vdate from STYLUS.CustTab where fname='"+fname.getText()+"' and lname='"+lname.getText()+"'and vdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'");
         rs1.next();
        if(gst.getText().equals("0")){
          /*  if(Integer.parseInt(amount.getText())>=1000){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nDiamond customer\n\n\tTHANK YOU");
            }
            else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nPlatinum customer\n\n\tTHANK YOU");
            }
            else  if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nGold customer\n\n\tTHANK YOU");
            }else{  */
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\n\n\tTHANK YOU");
         
            
         }else
        { /* if(Integer.parseInt(amount.getText())>=1000){
            rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nDiamond Customer\n\n\tTHANK YOU");
        }else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
            rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nPlatinum Customer\n\n\tTHANK YOU");
        }else if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
            rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\nGold customer\n\n\tTHANK YOU");
        }else{  */
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042 \n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs1.getDouble(1))+"\nGST("+(gstval*100)+"%):         "+(gstval*rs1.getDouble(1))+"\n------------------------------\nNet amount:      "+(rs1.getDouble(1)+gstval*(rs1.getDouble(1)))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs1.getString(2)+"\nRegular visit(10% OFF).\nFinal Amount:    "+((rs1.getDouble(1)+gstval*(rs1.getDouble(1)))-(.1*((rs1.getDouble(1))+gstval*(rs1.getDouble(1)))))+"\n\n\tTHANK YOU");
        
                   
        }
              
        }
        else{
        smt.setString(1,inv);
        smt.setString(2,fname.getText());
        smt.setString(3,lname.getText());
        smt.setDouble(4,(Integer.valueOf(amount.getText())));
        smt.setString(5,pmethod.getText());
       // smt.setString(5,vdate.getEditor().getText());
        if(male.isSelected()){
          smt.setString(6,male.getText());
        }else if(female.isSelected()){
          smt.setString(6,female.getText());
        }
         smt.setString(7,email.getText());
         smt.setDouble(8,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.1*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
          if(!loginmodel.isEmpInsertData(empid.getText(),String.valueOf(new Date(System.currentTimeMillis())))){
        try{
          PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
         
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,wk);
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.1*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
         }catch(Exception e){}
         }else{
           
              try{
               //   String getdataquery="select workdone,income from STYLUS.EmpStatus where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'"; 
       
                String getdataquery="select count(id) from STYLUS.EmpStatus";
               ResultSet rs1=conn.createStatement().executeQuery(getdataquery);
        rs1.next();
          // Double value=Double.parseDouble(amount.getText())+Double.valueOf(rs1.getString(2));
            int value1=Integer.valueOf(rs1.getString(1))+1;
            
           // String updatequery="update STYLUS.EmpStatus set workdone='"+String.valueOf(value1)+"',income='"+String.valueOf(value)+"'where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'";
               PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,String.valueOf(value1));
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-(.1*(Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText())))));
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
        
     
        //  PreparedStatement smt3= conn.prepareStatement(updatequery);
        // smt3.executeUpdate();
            }catch(Exception e){
            System.out.println(e);}
        
       }
      
         
         smt.execute();
          // String ph="+91"+email.getText();  
       //  SMS send =new SMS();
        //send.SendSMS("trinayanborah", "trinayan123", mes, ph , "https://bulksms.vsms.net/eapi/submission/send_sms/2/2.0");
       
       
        ResultSet rs1=conn.createStatement().executeQuery("select amount,vdate from STYLUS.CustTab where fname='"+fname.getText()+"' and lname='"+lname.getText()+"'and vdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'");
         rs1.next();
           if(gst.getText().equals("0")){
            /*   if(Integer.parseInt(amount.getText())>=1000){
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer\n\n\tTHANK YOU");    
               }
              else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum Customer\n\n\tTHANK YOU");    
               }else if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer\n\n\tTHANK YOU");    
               }else{  */
                     rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
        
               
         }else{
         /*  if(Integer.parseInt(amount.getText())>=1000){
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer\n\n\tTHANK YOU");    
          }else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum Customer\n\n\tTHANK YOU");    
          }else if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer\n\n\tTHANK YOU");    
          }else{  */
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
          
           }
         }
         }else{
           smt.setString(1,inv); 
          smt.setString(2,fname.getText());
        smt.setString(3,lname.getText());
        smt.setDouble(4,(Integer.valueOf(amount.getText())));
        smt.setString(5,pmethod.getText());
       // smt.setString(5,vdate.getEditor().getText());
        if(male.isSelected()){
          smt.setString(6,male.getText());
        }else if(female.isSelected()){
          smt.setString(6,female.getText());
        }
         smt.setString(7,email.getText());
         smt.setDouble(8,((Integer.valueOf(amount.getText())+.05*Integer.valueOf(amount.getText()))));
          
         if(!loginmodel.isEmpInsertData(empid.getText(),String.valueOf(new Date(System.currentTimeMillis())))){
         try{
         PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,wk);
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setString(5,amount.getText());
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
         }catch(Exception e){}
         }else{
           try{ 
               //String getdataquery="select workdone,income from STYLUS.EmpStatus where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'"; 
        String getdataquery="select count(id) from STYLUS.EmpStatus";
         ResultSet rs1=conn.createStatement().executeQuery(getdataquery);
        rs1.next();
           //Double value=Double.parseDouble(amount.getText())+Double.valueOf(rs1.getString(2));
            int value1=Integer.valueOf(rs1.getString(1))+1;
            
           // String updatequery="update STYLUS.EmpStatus set workdone='"+String.valueOf(value1)+"',income='"+String.valueOf(value)+"'where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'";
           
          PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,String.valueOf(value1));
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setString(5,amount.getText());
        smt2.setString(6,workcode.getText());
     
         // PreparedStatement smt3= conn.prepareStatement(updatequery);
         //smt3.executeUpdate();
          smt2.execute();
            }catch(Exception e){
            System.out.println(e);}
        
       }
       
         
         if(gst.getText().equals("0")){
        /* if(Integer.parseInt(amount.getText())>=1000){
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer \n\n\tTHANK YOU");    
         }else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum \n\n\tTHANK YOU");    
         } if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer \n\n\tTHANK YOU");    
         } else{  */
             rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
         
         }else{
          /*   if(Integer.parseInt(amount.getText())>=1000){
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer\n\n\tTHANK YOU");    
         } else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum Customer\n\n\tTHANK YOU");    
         }  if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer\n\n\tTHANK YOU");    
         }  else{  */
         rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
         
         }
         }
         
      }else{
       smt.setString(1,inv);
     smt.setString(2,fname.getText());
        smt.setString(3,lname.getText());
        smt.setDouble(4,(Integer.valueOf(amount.getText())));
        smt.setString(5,pmethod.getText());
       // smt.setString(5,vdate.getEditor().getText());
        if(male.isSelected()){
          smt.setString(6,male.getText());
        }else if(female.isSelected()){
          smt.setString(6,female.getText());
        }
         smt.setString(7,email.getText());
         smt.setDouble(8,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))));
         if(!loginmodel.isEmpInsertData(empid.getText(),String.valueOf(new Date(System.currentTimeMillis())))){
         try{
         PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,wk);
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))));
        smt2.setString(6,workcode.getText());        
//smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
         }catch(Exception e){}
         }else{
           try{ 
               //String getdataquery="select workdone,income from STYLUS.EmpStatus where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'"; 
         String getdataquery="select count(id) from STYLUS.EmpStatus";
               ResultSet rs1=conn.createStatement().executeQuery(getdataquery);
        rs1.next();
          // Double value=Double.parseDouble(amount.getText())+Double.valueOf(rs1.getString(2));
            int value1=Integer.valueOf(rs1.getString(1))+1;
            
           // String updatequery="update STYLUS.EmpStatus set workdone='"+String.valueOf(value1)+"',income='"+String.valueOf(value)+"'where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'";
           
           PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,String.valueOf(value1));
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))));
        smt2.setString(6,workcode.getText());
     
         // PreparedStatement smt3= conn.prepareStatement(updatequery);
         //smt3.executeUpdate();
          smt2.execute();
            }catch(Exception e){
            System.out.println(e);}
        
       }
       
         
         smt.execute();
        
            ResultSet rs=conn.createStatement().executeQuery("select rid,vdate,fname,lname,amount,pmethod,phone,tamount from STYLUS.CustTab where fname='"+fname.getText()+"' and lname='"+lname.getText()+"'");
          rs.next();
        /* java.util.Date d1=Date.valueOf(rs.getString(2));
         java.util.Date d2=new Date(System.currentTimeMillis());
         long days1=(d1.getTime()/(1000*60*60*24));
          long days2=(d2.getTime()/(1000*60*60*24));
          long days=Math.abs(days2-days1);
          System.out.println(days);*/
          //int valdate=(Integer.valueOf(rs.getString(2))-Integer.valueOf(new Date(System.currentTimeMillis())));
          if(gst.getText().equals("0")){
       /*  if(Integer.parseInt(amount.getText())>=1000){
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer\n\n\tTHANK YOU");    
         }else if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum Customer\n\n\tTHANK YOU");    
         }else if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer\n\n\tTHANK YOU");    
         } else{  */
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
         
          }else{
           /*   if(Integer.parseInt(amount.getText())>=1000){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer\n\n\tTHANK YOU");    
          } if(Integer.parseInt(amount.getText())<=1000 && Integer.parseInt(amount.getText())>=800){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum Customer\n\n\tTHANK YOU");    
          } if(Integer.parseInt(amount.getText())<=800 && Integer.parseInt(amount.getText())>=600){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer\n\n\tTHANK YOU");    
          } else{  */
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
          }
          
        }
          conn.close();
         lb.setText("Data Inserted Sucessfully");
        }
        else{
            
            
            Connection conn= dbConnect.Connector();  
         PreparedStatement smt= conn.prepareStatement(insertquery); 
           ResultSet rs3=conn.createStatement().executeQuery("select count(id)+1 from STYLUS.getid");
         rs3.next();
         int getvalue=Integer.parseInt(rs3.getString(1));
         String inv="STYLUS"+getvalue;
        PreparedStatement smt1= conn.prepareStatement("insert into STYLUS.getid(id) values(select (count(*)+1) from STYLUS.getid)");
         //smt1.setString(1,String.valueOf(getvalue));
         
         
         smt1.execute();
         double gstval=Double.valueOf(gst.getText())/100;
         double offval=Double.valueOf(offer.getText())/100;
         
         smt.setString(1,inv);
     smt.setString(2,fname.getText());
        smt.setString(3,lname.getText());
        smt.setDouble(4,(Integer.valueOf(amount.getText())));
        smt.setString(5,pmethod.getText());
       // smt.setString(5,vdate.getEditor().getText());
        if(male.isSelected()){
          smt.setString(6,male.getText());
        }else if(female.isSelected()){
          smt.setString(6,female.getText());
        }
         smt.setString(7,email.getText());
         smt.setDouble(8,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-offval*Integer.valueOf(amount.getText())));
         if(!loginmodel.isEmpInsertData(empid.getText(),String.valueOf(new Date(System.currentTimeMillis())))){
         try{
         PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,wk);
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-offval*Integer.valueOf(amount.getText())));
        smt2.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
        smt2.execute();
         }catch(Exception e){}
         }else{
           try{
               //String getdataquery="select workdone,income from STYLUS.EmpStatus where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'"; 
        String getdataquery="select count(id) from STYLUS.EmpStatus";
               ResultSet rs1=conn.createStatement().executeQuery(getdataquery);
        rs1.next();
          // Double value=Double.parseDouble(amount.getText())+Double.valueOf(rs1.getString(2));
            int value1=Integer.valueOf(rs1.getString(1))+1;
            
           // String updatequery="update STYLUS.EmpStatus set workdone='"+String.valueOf(value1)+"',income='"+String.valueOf(value)+"'where id='"+empid.getText()+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'";
            PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,empid.getText());
        smt2.setString(2,pr);
        smt2.setString(3,String.valueOf(value1));
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setDouble(5,((Integer.valueOf(amount.getText())+gstval*Integer.valueOf(amount.getText()))-offval*Integer.valueOf(amount.getText())));
        smt2.setString(6,workcode.getText());
     
       
         smt2.execute();
         // PreparedStatement smt3= conn.prepareStatement(updatequery);
         //smt3.executeUpdate();
            }catch(Exception e){
            System.out.println(e);}
        
       }
       
         
         smt.execute();
       
            ResultSet rs=conn.createStatement().executeQuery("select rid,vdate,fname,lname,amount,pmethod,phone,tamount from STYLUS.CustTab where fname='"+fname.getText()+"' and lname='"+lname.getText()+"'");
          rs.next();
        /* java.util.Date d1=Date.valueOf(rs.getString(2));
         java.util.Date d2=new Date(System.currentTimeMillis());
         long days1=(d1.getTime()/(1000*60*60*24));
          long days2=(d2.getTime()/(1000*60*60*24));
          long days=Math.abs(days2-days1);
          System.out.println(days);*/
          //int valdate=(Integer.valueOf(rs.getString(2))-Integer.valueOf(new Date(System.currentTimeMillis())));
          if(gst.getText().equals("0")){
          /*  if(Integer.parseInt(rs.getString(5))>=1000){
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer\n\n\tTHANK YOU");    
            } if(Integer.parseInt(rs.getString(5))<=1000 && Integer.parseInt(rs.getString(5))>=800){
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum Customer\n\n\tTHANK YOU");    
            } if(Integer.parseInt(rs.getString(5))<=800 && Integer.parseInt(rs.getString(5))>=600){
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer\n\n\tTHANK YOU");    
            } else{  */
              rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
            
          }else{
            /*  if(Integer.parseInt(rs.getString(5))>=1000){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nDiamond Customer\n\n\tTHANK YOU");    
          } if(Integer.parseInt(rs.getString(5))<=1000 && Integer.parseInt(rs.getString(5))>=800){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nPlatinum Customer\n\n\tTHANK YOU");    
          }  if(Integer.parseInt(rs.getString(5))<=800 && Integer.parseInt(rs.getString(5))>=600){
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\nGold Customer\n\n\tTHANK YOU");    
          } else{  */
          rece.setText("\tSTYLUS\n\nAdd:Geeta Complex,NT\nRoad Kharupetia,\nDarrang, Assam.\nPh no.:8402985042\n-------------------------------\nID: "+rs.getString(1)+"\nName: "+rs.getString(3)+"\nAmount(Rs.):     "+(rs.getDouble(5))+"\nGST("+(gstval*100)+"%):          "+(gstval*Double.valueOf(rs.getDouble(5)))+"\nOFFER("+(offval*100)+"%):          "+(offval*Double.valueOf(rs.getDouble(5)))+"\n------------------------------\nNet amount:      "+(rs.getInt(8))+"\nPayment:            "+rs.getString(6)+"\nDate:          "+rs.getString(2)+"\n\n\tTHANK YOU");    
          
          }
          conn.close();
         lb.setText("Data Inserted Sucessfully");
        }
        
        
        }
        else 
        {  lb.setText("Properly provide data");}
     }

    @FXML
    private void reset(ActionEvent event) {
        amount.setText("");
        fname.setText("");
        lname.setText("");
        pmethod.setText("");
        email.setText("");
        gst.setText("");
        empid.setText("");
        offer.setText("");
        rece.setText("");
        workcode.setText("");
        lb.setText("Customer Billing System");
        
    }
    
}
