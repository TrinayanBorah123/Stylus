/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stylusproject;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Trinayan
 */
public class BookingFXMLController implements Initializable {

    @FXML
    private Label lb;
    @FXML
    private JFXTextField fname;
    @FXML
    private JFXTextField lname;
    @FXML
    private JFXTextField email;
   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void reset(ActionEvent event) {
         fname.setText("");
        lname.setText("");
        email.setText("");
        lb.setText("Customer Billing System");
       // bdate.setValue(null);
    }

    @FXML
    private void Book(ActionEvent event) throws SQLException {
         String insertquery="insert into STYLUS.Booking(fname,lname,phone,bdate) values(?,?,?,CURRENT_DATE)";
        if(!fname.getText().isEmpty() && !lname.getText().isEmpty() && !email.getText().isEmpty()){
          Connection conn= dbConnect.Connector();  
         PreparedStatement smt= conn.prepareStatement(insertquery);
         smt.setString(1,fname.getText());
        smt.setString(2,lname.getText());
        smt.setString(3,email.getText());
        //smt.setString(4,bdate.getEditor().getText());
          smt.execute();
          conn.close();
        lb.setText("Booked Sucessfully");
        }else{
        lb.setText("Give proper inputs!!");
        }
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
        ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("FXMLDocument.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    @FXML
    private void Bookview(ActionEvent event) throws IOException{
        ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("BookingdataFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    
}
