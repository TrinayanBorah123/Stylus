
package stylusproject;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class EmployeeRegisterFXMLController implements Initializable {

    @FXML
    private Pane lab;
    @FXML
    private Label lb;
    @FXML
    private JFXTextField id;
    @FXML
    private JFXTextField fname;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXTextField lname;
    @FXML
    private JFXPasswordField pass;

    public LoginModel loginmodel=new LoginModel();
     private dbConnect connection;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
          this.connection=new dbConnect();
    }    

    @FXML
    private void insert(ActionEvent event) throws SQLException {
          if(!loginmodel.isEmpStatusInsert(id.getText())&&!id.getText().isEmpty() && !fname.getText().isEmpty() && !lname.getText().isEmpty() && !pass.getText().isEmpty() && !email.getText().isEmpty()){
       String queryInsert="insert into STYLUS.EmpTab(id,password,fname,lname,email) values(?,?,?,?,?)";
       try{
         Connection conn= dbConnect.Connector();  
         PreparedStatement smt= conn.prepareStatement(queryInsert); 
        smt.setString(1,id.getText());
        smt.setString(2,pass.getText());
        smt.setString(3,fname.getText());
        smt.setString(4,lname.getText());
        smt.setString(5,email.getText());
        smt.execute();
        conn.close();
        lb.setText("Data Inserted Sucessfully");
      }catch(SQLException ex)
      {  System.out.println(ex); 
      }
      }
      else{
          lb.setText("Properly provide data");
        
      }
    
    }

    @FXML
    private void reset(ActionEvent event) {
        
        id.setText("");
        pass.setText("");
        fname.setText("");
        lname.setText("");
        email.setText("");
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
          
       ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeLoginFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    
}
