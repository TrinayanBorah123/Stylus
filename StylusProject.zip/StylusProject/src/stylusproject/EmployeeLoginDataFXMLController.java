
package stylusproject;

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import static stylusproject.EmployeeLoginFXMLController.sid;

public class EmployeeLoginDataFXMLController implements Initializable {

    @FXML
    private Pane lab;
    @FXML
    private TableView<EmpStatusUserData> EmpStatustable;
    @FXML
    private TableColumn<EmpStatusUserData, String> datecolumn;
    @FXML
    private TableColumn<EmpStatusUserData, String> workdonecolumn;
    @FXML
    private TableColumn<EmpStatusUserData, String> statuscolumn;
    @FXML
    private TableColumn<EmpStatusUserData, String> incomecolumn;
    @FXML
    private TableColumn<EmpStatusUserData, String> worktypecolumn;
      private ObservableList<EmpStatusUserData> data;
    @FXML
    private Label lb;
    private JFXTextField workcode;

    private dbConnect connection;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.connection=new dbConnect();
    }    
    public LoginModel loginmodel=new LoginModel();
    @FXML
    private void addData(ActionEvent event) throws SQLException {
         //String wk="0";
       // String in="0";
       // String queryInsert="insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)";
        //  String c_date="select TO_CHAR(sysdate,'DD-MM-YYYY HH:MI:SS'),TO_CHAR(sysdate,'DD-MM-YYYY') from dual";
        //String c_date="select current_date";
       
        Connection conn= dbConnect.Connector(); 
          //ResultSet rs=conn.createStatement().executeQuery(c_date);2
          //rs.next();
           //String w_date="values current_timestamp";
         // ResultSet rs3=conn.createStatement().executeQuery(w_date);
          if(loginmodel.isEmpInsertData(sid,String.valueOf(new Date(System.currentTimeMillis())))){
         
         try{
         
       //  String pr="Present";
        
      //  PreparedStatement smt= conn.prepareStatement(queryInsert); 
      //  smt.setString(1,sid);
      //  smt.setString(2,pr);
      //  smt.setString(3,wk);
      //  smt.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
      //  smt.setString(5,in);
       //  smt.setString(6,workcode.getText());
        //smt.setString(6,String.valueOf(new Date(System.currentTimeMillis())));
       //smt.setString(6,String.valueOf(sdf.format(Edate)));
      //  smt.execute();
         this.data = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select cdate,workdone,status,income,worktype from STYLUS.EmpStatus where id='"+sid+"' and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'");
        while(rs2.next()){
          this.data.add(new EmpStatusUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4),rs2.getString(5)));
          }
         this.datecolumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        this.workdonecolumn.setCellValueFactory(new PropertyValueFactory("workdone"));
        this.statuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        this.incomecolumn.setCellValueFactory(new PropertyValueFactory<>("income"));
        this.worktypecolumn.setCellValueFactory(new PropertyValueFactory<>("worktype"));
        //this.studenttable.setItems(null);
        this.EmpStatustable.setItems(this.data);
        
        conn.close();
        lb.setText("Data Initialized Sucessfully");
      }catch(SQLException ex)
      {  System.out.println(ex); 
      }
     }else
      {   
        /*  this.data = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select cdate,workdone,status,income,worktype from STYLUS.EmpStatus where id='"+sid+"' and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'");
        while(rs2.next()){
          this.data.add(new EmpStatusUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4),rs2.getString(5)));
          }
         this.datecolumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        this.workdonecolumn.setCellValueFactory(new PropertyValueFactory("workdone"));
        this.statuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        this.incomecolumn.setCellValueFactory(new PropertyValueFactory<>("income"));
         this.worktypecolumn.setCellValueFactory(new PropertyValueFactory<>("worktype"));
        //this.studenttable.setItems(null);
        this.EmpStatustable.setItems(this.data);
        conn.close();  */
        
          lb.setText("NO work found!!");   }
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
        ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeLoginFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }

    /*@FXML
    private void update(ActionEvent event) throws SQLException {
          Connection conn= dbConnect.Connector(); 
        //ResultSet rs=conn.createStatement().executeQuery(c_date);
        //rs.next();
          String getdataquery="select count(id) from STYLUS.EmpStatus";
       // String getdataquery="select workdone,income from STYLUS.EmpStatus where id='"+sid+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'"; 
        ResultSet rs1=conn.createStatement().executeQuery(getdataquery);
        rs1.next();
        if(!workcode.getText().isEmpty()&& !amount.getText().isEmpty() && loginmodel.isEmpInsertData(sid,String.valueOf(new Date(System.currentTimeMillis())))){
            
          //  Double value=Double.parseDouble(amount.getText())+Double.valueOf(rs1.getString(2));
            int value1=Integer.valueOf(rs1.getString(1))+1;
            
           // String updatequery="update STYLUS.EmpStatus set workdone='"+String.valueOf(value1)+"',income='"+String.valueOf(value)+"'where id='"+sid+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'";
           
            try{
     
      //PreparedStatement smt= conn.prepareStatement(updatequery);
      //smt.executeUpdate();
          PreparedStatement smt2=conn.prepareStatement("insert into STYLUS.EmpStatus(id,status,workdone,cdate,income,wdate,worktype) values(?,?,?,?,?,CURRENT_DATE,?)");
        
        String pr="Present";
        smt2.setString(1,sid);
        smt2.setString(2,pr);
        smt2.setString(3,String.valueOf(value1));
        smt2.setString(4,String.valueOf(new Timestamp(System.currentTimeMillis())));
        smt2.setString(5,amount.getText());
        smt2.setString(6,workcode.getText());
          smt2.execute();
        this.data = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select cdate,workdone,status,income,worktype from STYLUS.EmpStatus where id='"+sid+"'and wdate='"+String.valueOf(new Date(System.currentTimeMillis()))+"'");
        while(rs2.next()){
          this.data.add(new EmpStatusUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4),rs2.getString(5)));
          }
        }catch(SQLException e){
        System.out.println(e);
        }
         
        this.datecolumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        this.workdonecolumn.setCellValueFactory(new PropertyValueFactory("workdone"));
        this.statuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        this.incomecolumn.setCellValueFactory(new PropertyValueFactory<>("income"));
        this.worktypecolumn.setCellValueFactory(new PropertyValueFactory<>("worktype"));
        //this.studenttable.setItems(null);
        this.EmpStatustable.setItems(this.data);
       
        conn.close();
      lb.setText("Increase Sucessfully");
     }else{
       lb.setText("Error in Increasing!!");
       }
      
    }

    @FXML
    private void search(ActionEvent event) throws IOException {
            ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeStatusFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
 */
    @FXML 
 private void passchg(ActionEvent event) throws IOException{
     ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmpPassChngFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    
     
 }

}
