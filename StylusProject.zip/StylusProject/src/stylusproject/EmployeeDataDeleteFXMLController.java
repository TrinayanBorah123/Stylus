
package stylusproject;

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class EmployeeDataDeleteFXMLController implements Initializable {

    @FXML
    private JFXTextField id;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    @FXML
    private Label isConnected;
    @FXML
    private void home(ActionEvent event) throws IOException{
      ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("OwnerLoginDataFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    LoginModel loginmodel=new LoginModel();
    @FXML
    private void delete(ActionEvent event) throws SQLException{
        String delete="delete from STYLUS.EmpTab where id='"+id.getText()+"'";
        String deleteempstatus="delete from STYLUS.EmpStatus where id='"+id.getText()+"'";
        if(loginmodel.isEmpStatusInsert(id.getText()) &&!id.getText().isEmpty()){ 
        try{
         Connection conn= dbConnect.Connector();  
         PreparedStatement smt= conn.prepareStatement(delete); 
        PreparedStatement smt1= conn.prepareStatement(deleteempstatus);
        smt1.execute();
        smt.execute();
        isConnected.setText("Sucessfully deleted.");
         }catch(Exception e){
         }}else{
         isConnected.setText("Error in deleteing!!.");
        }
    
    }
    
}
