
package stylusproject;

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class BookingdataFXMLController implements Initializable {

    @FXML
    private Pane lab;
    @FXML
    private TableView<BookedCustomerUserData> BookedCusttable;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Bfnamecolumn;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Blnamecolumn;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Bphonecolumn;
    @FXML
    private TableColumn<BookedCustomerUserData, String> Bdatecolumn;
    @FXML
    private JFXTextField fn;
    @FXML
    private JFXTextField ph;
    @FXML
    private Label st;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    private ObservableList<BookedCustomerUserData> data1;
    
    @FXML
    private void loaddata2(ActionEvent event) throws SQLException {
          Connection conn= dbConnect.Connector();
        this.data1 = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select fname,lname,phone,bdate from STYLUS.Booking");
        while(rs2.next()){
          this.data1.add(new BookedCustomerUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4)));
          }
         this.Bfnamecolumn.setCellValueFactory(new PropertyValueFactory<>("fname"));
        this.Blnamecolumn.setCellValueFactory(new PropertyValueFactory("lname"));
        this.Bphonecolumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        this.Bdatecolumn.setCellValueFactory(new PropertyValueFactory<>("bdate"));
        //this.studenttable.setItems(null);
        this.BookedCusttable.setItems(this.data1);
        conn.close();
    }
     public LoginModel loginmodel=new LoginModel();
    @FXML
    private void delete2(ActionEvent event) throws SQLException {
          if(loginmodel.isBookDelete(fn.getText(),ph.getText())&&!fn.getText().isEmpty() && !ph.getText().isEmpty()){
       String delete="delete from STYLUS.Booking where fname='"+fn.getText()+"'and phone='"+ph.getText()+"'";
       try{
         Connection conn= dbConnect.Connector();  
         PreparedStatement smt= conn.prepareStatement(delete); 
       
        smt.execute();
         this.data1 = FXCollections.observableArrayList();
        ResultSet rs2=conn.createStatement().executeQuery("select fname,lname,phone,bdate from STYLUS.Booking");
        while(rs2.next()){
          this.data1.add(new BookedCustomerUserData(rs2.getString(1),rs2.getString(2),rs2.getString(3),rs2.getString(4)));
          }
         this.Bfnamecolumn.setCellValueFactory(new PropertyValueFactory<>("fname"));
        this.Blnamecolumn.setCellValueFactory(new PropertyValueFactory("lname"));
        this.Bphonecolumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        this.Bdatecolumn.setCellValueFactory(new PropertyValueFactory<>("bdate"));
        //this.studenttable.setItems(null);
        this.BookedCusttable.setItems(this.data1);
        conn.close();
        st.setText("Data deleted Sucessfully");
      }catch(SQLException ex)
      {  System.out.println(ex); 
      }
      }
      else{
          st.setText("Properly provide data");
        
      }
       
    }

    @FXML
    private void signout(ActionEvent event) throws IOException {
         ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("BookingFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    
}
