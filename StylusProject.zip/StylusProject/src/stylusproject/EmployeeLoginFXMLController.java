
package stylusproject;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class EmployeeLoginFXMLController implements Initializable {

    @FXML
    private Pane lab;
    @FXML
    private Label isConnected;
    @FXML
    private JFXTextField id;
    @FXML
    private JFXPasswordField password;
     public static String sid="";
    public LoginModel loginmodel=new LoginModel();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void login(ActionEvent event) throws SQLException {
        if(!id.getText().isEmpty() && !password.getText().isEmpty() && loginmodel.isLoginEmp(id.getText(), password.getText())){
        try{
           sid=id.getText();
       ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeLoginDataFXML.fxml").openStream());
       Scene scene = new Scene(root);
       
       // scene.getStylesheets().add(getClass().getResource("design.css").toExternalForm());
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
      }catch(IOException e){
          System.out.println(e);
      } 
      }
      else
      {  isConnected.setText("Give proper inputs!!");
      }
    }

    @FXML
    private void home(ActionEvent event) throws IOException {
        
       ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("FXMLDocument.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }

    @FXML
    private void signup(ActionEvent event) throws IOException {
          ((Node)event.getSource()).getScene().getWindow().hide();
       Stage primarystage=new Stage();
       FXMLLoader loader=new FXMLLoader();
       Pane root = loader.load(getClass().getResource("EmployeeRegisterFXML.fxml").openStream());
       Scene scene = new Scene(root);
       primarystage.setTitle("Market Management");
       primarystage.setScene(scene);
       primarystage.show();
    }
    
}
