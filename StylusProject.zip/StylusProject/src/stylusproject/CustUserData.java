
package stylusproject;


public class CustUserData {
     private String name;
    private String phone;
    private String cost;
      public CustUserData(String Name,String Phone,String Cost){
       this.name=Name;
       this.phone=Phone;
       this.cost=Cost;
    
      }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the cost
     */
    public String getCost() {
        return cost;
    }

    /**
     * @param cost the cost to set
     */
    public void setCost(String cost) {
        this.cost = cost;
    }
      
}
